package robotoo;

class Pierna_OO {
    private int longitud;
    private int velocidad;

    // Constructor
    public Pierna_OO(int longitud, int velocidad) {
        this.longitud = longitud;
        this.velocidad = velocidad;
    }

    // Método para caminar
    public void caminar() {
        System.out.println("Caminando con la pierna a velocidad: " + velocidad);
    }
}
