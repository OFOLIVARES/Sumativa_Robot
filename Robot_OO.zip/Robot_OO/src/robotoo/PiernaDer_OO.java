package robotoo;

class PiernaDer_OO extends Pierna_OO {
    private PieDer_OO pieDer;

    // Constructor
    public PiernaDer_OO(int longitud, int velocidad, PieDer_OO pieDer) {
        super(longitud, velocidad);
        this.pieDer = pieDer;
    }
}