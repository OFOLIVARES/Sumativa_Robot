package robotoo;

class Dedo_OO {
    private String lado;
    private int numero;

    // Constructor
    public Dedo_OO(String lado, int numero) {
        this.lado = lado;
        this.numero = numero;
    }

    // Método para mostrar información del dedo
    public void mostrarInfo() {
        System.out.println("Dedo " + numero + " del lado " + lado);
    }
}
