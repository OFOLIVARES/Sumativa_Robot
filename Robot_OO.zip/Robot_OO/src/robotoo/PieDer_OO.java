package robotoo;

class PieDer_OO extends Pie_OO {
    // Constructor
    public PieDer_OO(int numDedos) {
        super(numDedos);
        for (int i = 0; i < numDedos; i++) {
            super.dedos[i] = new Dedo_OO("Derecho", i + 1);
        }
    }
}
