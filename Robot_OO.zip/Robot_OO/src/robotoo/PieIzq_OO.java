package robotoo;

class PieIzq_OO extends Pie_OO {
    // Constructor
    public PieIzq_OO(int numDedos) {
        super(numDedos);
        for (int i = 0; i < numDedos; i++) {
            super.dedos[i] = new Dedo_OO("Izquierdo", i + 1);
        }
    }
}
