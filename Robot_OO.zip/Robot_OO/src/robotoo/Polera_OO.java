package robotoo;

class Polera_OO extends Outfit_OO {
    public Polera_OO(String color) {
        super("Polera", color);
    }
}

