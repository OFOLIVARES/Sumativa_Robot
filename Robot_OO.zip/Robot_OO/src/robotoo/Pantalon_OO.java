package robotoo;

class Pantalon_OO extends Outfit_OO {
 public Pantalon_OO(String color) {
     super("Pantalón", color);
 }
}