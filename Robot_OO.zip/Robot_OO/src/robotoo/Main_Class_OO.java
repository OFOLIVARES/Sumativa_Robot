package robotoo;

public class Main_Class_OO {
    public static void main(String[] args) {
        // Crear componentes del robot
        Torso_OO torso = new Torso_OO("Acero", 100);
        ManoIzq_OO manoIzq = new ManoIzq_OO(5);
        ManoDer_OO manoDer = new ManoDer_OO(5);
        BrazoIzq_OO brazoIzq = new BrazoIzq_OO(70, 50, manoIzq);
        BrazoDer_OO brazoDer = new BrazoDer_OO(70, 50, manoDer);
        PieIzq_OO pieIzq = new PieIzq_OO(5);
        PieDer_OO pieDer = new PieDer_OO(5);
        PiernaIzq_OO piernaIzq = new PiernaIzq_OO(90, 30, pieIzq);
        PiernaDer_OO piernaDer = new PiernaDer_OO(90, 30, pieDer);
        Cabeza_OO cabeza = new Cabeza_OO("LED", "Sintética");

        // Crear un robot con los componentes
        Robot_OO robot = new Robot_OO(torso, brazoIzq, brazoDer, piernaIzq, piernaDer, cabeza);

        // Crear outfit
        Polera_OO polera = new Polera_OO("Blanco");
        Pantalon_OO pantalon = new Pantalon_OO("Negro");

        // Vestir al robot
        robot.vestirse(polera);
        robot.vestirse(pantalon);  
    }
}
