package robotoo;

class BrazoIzq_OO extends Brazo_OO {
    private ManoIzq_OO manoIzq;

    // Constructor
    public BrazoIzq_OO(int longitud, int fuerza, ManoIzq_OO manoIzq) {
        super(longitud, fuerza);
        this.manoIzq = manoIzq;
    }
}