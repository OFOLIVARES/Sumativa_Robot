package robotoo;

class Outfit_OO {
    private String type;
    private String color;

    // Constructor
    public Outfit_OO(String type, String color) {
        this.type = type;
        this.color = color;
    }

    // Método para usar el outfit
    public void wear() {
        System.out.println("Usando atuendo " + type + " de color " + color);
    }

    // Getter para el tipo de outfit
    public String getType() {
        return type;
    }
    
    // Getter para el color de las prendas
    public String getColor() {
        return color;
    }
}
