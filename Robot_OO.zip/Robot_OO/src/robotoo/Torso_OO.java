package robotoo;

class Torso_OO {
    private String material;
    private int resistencia;

    // Constructor
    public Torso_OO(String material, int resistencia) {
        this.material = material;
        this.resistencia = resistencia;
    }

    // Método para mostrar información del torso
    public void mostrarInfo() {
        System.out.println("Torso de material: " + material + ", resistencia: " + resistencia);
    }
}
