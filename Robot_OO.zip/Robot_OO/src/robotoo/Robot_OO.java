package robotoo;

class Robot_OO {
    private Torso_OO torso;
    private BrazoIzq_OO brazoIzq;
    private BrazoDer_OO brazoDer;
    private PiernaIzq_OO piernaIzq;
    private PiernaDer_OO piernaDer;
    private Cabeza_OO cabeza;
    private Outfit_OO outfit;

    // Constructor
    public Robot_OO(Torso_OO torso, BrazoIzq_OO brazoIzq, BrazoDer_OO brazoDer, PiernaIzq_OO piernaIzq, PiernaDer_OO piernaDer, Cabeza_OO cabeza) {
        this.torso = torso;
        this.brazoIzq = brazoIzq;
        this.brazoDer = brazoDer;
        this.piernaIzq = piernaIzq;
        this.piernaDer = piernaDer;
        this.cabeza = cabeza;
    }

    // Método para hacer tarea
    public void hacerAlgo(String hacer) {
        System.out.println("El robot está realizando la tarea: " + hacer);
    }

    // Método para vestir al robot con outfit
    public void vestirse(Outfit_OO vestir) {
        outfit = vestir;
        System.out.println("El robot está usando una " + outfit.getType() + " de color " + outfit.getColor());
    }
}