package robotoo;

class Cabeza_OO {
    private String tipoOjos;
    private String tipoBoca;

    // Constructor
    public Cabeza_OO(String tipoOjos, String tipoBoca) {
        this.tipoOjos = tipoOjos;
        this.tipoBoca = tipoBoca;
    }

    // Método para mostrar información de la cabeza
    public void mostrarInfo() {
        System.out.println("Cabeza con ojos de tipo: " + tipoOjos + " y boca de tipo: " + tipoBoca);
    }
}