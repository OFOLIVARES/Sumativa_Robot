package robotoo;

class ManoDer_OO extends Mano_OO {
    // Constructor
    public ManoDer_OO(int numDedos) {
        super(numDedos);
        for (int i = 0; i < numDedos; i++) {
            super.dedos[i] = new Dedo_OO("Derecho", i + 1);
        }
    }
}