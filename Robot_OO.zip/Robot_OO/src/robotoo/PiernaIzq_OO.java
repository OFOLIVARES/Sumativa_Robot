package robotoo;

class PiernaIzq_OO extends Pierna_OO {
	 private PieIzq_OO pieIzq;
	
	 // Constructor
	 public PiernaIzq_OO(int longitud, int velocidad, PieIzq_OO pieIzq) {
	     super(longitud, velocidad);
	     this.pieIzq = pieIzq;
	 }
}