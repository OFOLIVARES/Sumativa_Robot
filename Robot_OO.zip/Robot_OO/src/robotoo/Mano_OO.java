package robotoo;

class Mano_OO {
    private int numDedos;
    protected Dedo_OO[] dedos;

    // Constructor
    public Mano_OO(int numDedos) {
        this.numDedos = numDedos;
        this.dedos = new Dedo_OO[numDedos];
        for (int i = 0; i < numDedos; i++) {
            dedos[i] = new Dedo_OO("Indefinido", i + 1);
        }
    }

    // Método para mostrar información de la mano
    public void mostrarInfo() {
        System.out.println("Mano con " + numDedos + " dedos.");
        for (Dedo_OO dedo : dedos) {
            dedo.mostrarInfo();
        }
    }
}