package robotoo;

class BrazoDer_OO extends Brazo_OO {
    private ManoDer_OO manoDer;

    // Constructor
    public BrazoDer_OO(int longitud, int fuerza, ManoDer_OO manoDer) {
        super(longitud, fuerza);
        this.manoDer = manoDer;
    }
}