package robotoo;

class Brazo_OO {
    private int longitud;
    private int fuerza;

    // Constructor
    public Brazo_OO(int longitud, int fuerza) {
        this.longitud = longitud;
        this.fuerza = fuerza;
    }

    // Método para mover el brazo
    public void mover() {
        System.out.println("Moviendo el brazo con fuerza: " + fuerza);
    }
}